@extends('master')
@section('content')
<h2>To jest strona o nas</h2>
@stop