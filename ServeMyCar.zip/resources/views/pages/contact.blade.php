@extends('master')
@section('content')
<h2>To jest strona kontakt</h2>
@stop