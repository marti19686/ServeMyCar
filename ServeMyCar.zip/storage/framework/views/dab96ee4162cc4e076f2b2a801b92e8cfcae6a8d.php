<?php $__env->startSection('content'); ?>
    
<div class="videos-header card">
    <h2>Moje Zlecenia</h2>
</div>

<?php if(Session::has('work_created')): ?>
    <div class="alert alert-success  card">
        <?php echo e(Session::get('work_created')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('work_edited')): ?>
    <div class="alert alert-primary  card">
        <?php echo e(Session::get('work_edited')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('work_deleted')): ?>
    <div class="alert alert-danger  card">
        <?php echo e(Session::get('work_deleted')); ?>

    </div>
<?php endif; ?>

<div class="row">

    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Single work -->
        <div class="col-xs-12 col-md-6 col-lg-4 single-video">
        <div class="card">
        
            <div class="card-content">
                <a href="<?php echo e(url('works', $work->id)); ?>">
                    <h4><?php echo e($work->title); ?></h4>
                </a>
                <p><?php echo e(str_limit($work->description, $limit=30)); ?></p>
                <span class="upper-label">Dodał</span>
                <span class="video-author"><?php echo e($work->user->name); ?>k</span>
            </div>
            
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projekty\ServeMyCar\kurs_laravel\resources\views/works/userShow.blade.php ENDPATH**/ ?>