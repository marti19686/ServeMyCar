<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 videos-header card">
        <h2><?php echo e($work->title); ?></h2>
    </div>

    <div class="row">

        <!-- left col. -->
        <div class="col-xs-12 col-md-12 single-video-left">

            <div class="card">

                <div class="single-video-content">
                    <h4>Pełny opis naprawy</h4>
                    <p><?php echo e($work->description); ?></p>
                    <h5>Dane kontaktowe klienta</h5>
                    <p><?php echo e($work->client_name); ?></p>
                    <p><?php echo e($work->client_contact); ?></p>
                    <span class="upper-label">Dodał</span>
                    <span class="video-author"><?php echo e($work->user->name); ?></span>
                    <div class="edit-button">
                        <?php if(Auth::User() == true && Auth::User()->id == $work->user_id): ?>
                        <a href="<?php echo e(action('WorksController@edit', $work->id)); ?>" class="btn btn-success btn-lg">
                            Edytuj Zlecenie
                        </a>
                        <a href="<?php echo e(action('WorksController@delete', $work->id)); ?>" class="btn btn-danger btn-lg">
                                Zakończ Zlecenie
                        </a>                        
                    <?php endif; ?>
                    </div>
                </div>
                
            </div>
            
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projekty\ServeMyCar\kurs_laravel\resources\views/works/show.blade.php ENDPATH**/ ?>