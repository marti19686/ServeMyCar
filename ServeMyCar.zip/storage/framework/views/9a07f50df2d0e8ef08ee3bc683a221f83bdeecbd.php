<?php $__env->startSection('content'); ?>
<h2>To jest strona o nas</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projekty\ServeMyCar\kurs_laravel\resources\views/pages/about.blade.php ENDPATH**/ ?>