<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="card">
                <div class="panel-body">
                <!-- Formularz -->
                <?php echo $__env->make('works.form_errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo Form::open(['url'=>'works', 'class'=>'form-horizontal']); ?>


                <?php echo $__env->make('works.form', ['buttonText'=>'Dodaj zlecenie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projekty\ServeMyCar\kurs_laravel\resources\views/works/create.blade.php ENDPATH**/ ?>